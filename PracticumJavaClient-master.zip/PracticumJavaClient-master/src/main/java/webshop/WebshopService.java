/**
 * WebshopService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package webshop;

public interface WebshopService extends javax.xml.rpc.Service {
    public java.lang.String getBasicHttpBinding_IwebshopServiceAddress();

    public webshop.IwebshopService getBasicHttpBinding_IwebshopService() throws javax.xml.rpc.ServiceException;

    public webshop.IwebshopService getBasicHttpBinding_IwebshopService(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
